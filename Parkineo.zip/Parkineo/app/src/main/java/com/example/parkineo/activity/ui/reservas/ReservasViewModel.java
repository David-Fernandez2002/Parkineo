package com.example.parkineo.activity.ui.reservas;

import androidx.lifecycle.ViewModel;

public class ReservasViewModel extends ViewModel {

    public ReservasViewModel() {

    }

}