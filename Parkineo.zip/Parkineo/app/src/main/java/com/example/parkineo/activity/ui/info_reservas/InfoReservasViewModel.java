package com.example.parkineo.activity.ui.info_reservas;

import androidx.lifecycle.ViewModel;

public class InfoReservasViewModel extends ViewModel {

    public InfoReservasViewModel() {

    }
}