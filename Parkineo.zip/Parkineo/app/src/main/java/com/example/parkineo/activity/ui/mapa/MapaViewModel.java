package com.example.parkineo.activity.ui.mapa;

import androidx.lifecycle.ViewModel;

public class MapaViewModel extends ViewModel {

    public MapaViewModel() {

    }

}